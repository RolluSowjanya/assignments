let fact = (n) => console.log(`factorial of : ${n} is ${( n*(n-1)*(n-2))}`);
fact(8);