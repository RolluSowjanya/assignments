function display(...args) {

    for (const e of args) {

        console.log(e );

    }



    console.log(`Total  Number of Arguments Passed : ${args.length}`);



}



display(1, 2, 3, 4, 5, 6, 7, 8,9,10);