const car = {
    vehicleid: 1234,
    brand: 'swift',
    model: '2010',
    variant: 'Top Model-CNG',

specifications: {

    firstGear: function () {
        console.log('vehicle is the first gear');

    },
    secondGear: function() {
        console.log('vehicle is the second gear');
    },
    maximumSpeed: 60,
        changeGear: function() {
            return (this.firstGear(), this.secondGear());

        },
}
}

console.log('vehicle details');
console.log(`brand:${car.brand}`);
console.log(`model:${car.model}`);
console.log(`model:${car.variant}`);
console.log(car.specifications.maximumSpeed);