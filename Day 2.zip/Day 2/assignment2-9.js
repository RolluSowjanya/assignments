function displayMax(arg1, arg2, arg3) {
    return Math.max(arg1, arg2, arg3);
}

console.log(`maximum number is :${displayMax(2, 5, 8)}`);