const sum = (a,b) => a + b;
console.log('sum :' + sum(5,10));