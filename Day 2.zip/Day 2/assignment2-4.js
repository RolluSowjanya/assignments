
function login(username='CT',password='CT')
{
    console.log(' user name : '+username);
    console.log(' password :'+password); 
}
login('sowjanya','4532');
login();