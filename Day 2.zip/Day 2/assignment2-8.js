function sum(...a) {
    res = 0;
    for (i = 0; i < a.length; i++) {
        res += a[i];
    }
    console.log(`The Sum = ${res}`);
}
sum(2, 45, 8);
sum();