var array=[6,5,78,10,15,8,9,11,23,45];
var first=0;
var second=0;
for(var i=0;i<array.length;i++){
    var current=array[i];
    if(first<current){
        second=first;
        first=current;

    }
    else if(second<current){
        second=current;

    }

}
document.write("array:"+array,"</br>");
document.write("first greatest number is :"+first,"</br>");
document.write("second greatest number is :"+second,"</br>");