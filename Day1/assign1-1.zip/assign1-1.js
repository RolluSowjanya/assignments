let i;
let divider,flag;
for( i=5; i<=50 ; i++)
{
    for(divider=2;divider<i;divider++)
    {

    
    if(i%divider==0)
    {
        flag==1;
        break;
    }
    else{
        flag=0;
        console.log("prime number are:" + i);
        break;

    }



    }

}